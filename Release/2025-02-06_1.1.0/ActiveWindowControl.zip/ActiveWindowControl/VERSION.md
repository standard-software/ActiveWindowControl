## Version

### 1.1.0
- Update: Fixed closing menu when switching active window

### 1.0.0
- Add Display SubMenu
  - Same Position
  - Fit / Snap
- Update: Disabled the setting of the Parent window in the foreground.
- Update: README

### 0.15.1
2025/01/29 Wed
- Update MenuItem Name: -> Vertical Center
- Add README & ScreenShot

### 0.15.0
2025/01/29 Wed
- fix fit window
- update snap window menu
- ActiveWindowControl window topmost
- Changed display menu. 
  - Enabled specification of multiple displays

### 0.14.0
2025/01/21 Tue
- tray icon double click to restart
- change menu item center
- change menu title resize -> snap
- add fit Left/Right Corner

### 0.13.0
2024/09/13 Fri
- update move to prev/next monitor

### 0.12.0
2024/09/06 Fri  
- Position it above the maximise button.

### 0.11.0
- update menu item
  - delete top item Center Horizntal

### 0.10.0
- Add Menu Top
  - Left / Center Horizontal / Right

### 0.9.0
- update menu item name

### 0.8.1
- update tasktray icon ux
- Add Menu Top
  - About

### 0.8.0
- update tasktray icon ux
- Add Menu
  - Center Horizontal
  - Center Vertical

### 0.7.0
- Delete Menu Top
  - About / Exit
  - use tray icon menu it
- Screen Sort XY

### 0.6.1
- MouseMove Open Menu
  - adjust Time

### 0.6.0
- MouseMove Open Menu

### 0.5.0
- Delete Menu
  - Favorite MenuItem

### 0.4.0
- Add Menu Top
  - Size 90% TopLeft
  - Size 90% BottomRight

### 0.3.0
- Monitor Count 2 and 3 Change Menu
- Add Resize 30% 70%
- Mouse Hover Change Opacity
- Dark Mode Thema

### 0.2.0
- Add Tasktray & menu
  - About
  - Restart
  - Exit

- update Timer Tracking
  - Fix missing window (problem window state minimize)
  - update not tracking resizeframe (WS_THICKFRAME) window

### 0.1.0
2022/12/23 Fri

- Split Screen Area
  - Left Side
  - Right Side
  ---
  - Top Side
  - Bottom Side
  ---
  - TopLeft Side
  - TopRight Side
  - BottomLeft Side
  - BottomRight Side
- Resize Window
  - Size 90%
    - Center
    ---
    - Left Side
    ...
  - Size 75%
  - Size 50%
  - Size 25%
---
- Move To Prev Monitor
  - Same Position
  - Maximize
- Move To Next Monitor
  ...
---
- About
- Exit

